import Header from "./components/Header/Header";
import AllSections from "./components/AllSections/AllSections";
import "./App.css";
import "./commonResources/css/styles.css";
import "./commonResources/css/bootstrap.css";
import "./commonResources/js/bootstrap.js";

import Footer from "./components/Footer/Footer";
function App() {
  return (
    <div>
      <Header />
      <AllSections />
      <Footer />
    </div>
  );
}

export default App;
