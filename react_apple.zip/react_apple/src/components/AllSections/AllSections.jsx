import React from "react";
// import "./AllSections.css";
import Alert from "./Alert/Alert";
import SectionOne from "./SectionOne/NewiPadPro";
import SectionTwo from "./SectionTwo/NewMacBookAir";
import SectionThree from "./SectionThree/IPhone11Pro";
import SectionFour from "./SectionFour/SectionFour";
import SectionFive from "./SectionFive/SectionFive";
import SectionSix from "./SectionSix/SectionSix";

function AllSections() {
  return (
    <>
      <Alert />
      <SectionOne />
      <SectionTwo />
      <SectionThree />
      <SectionFour />
      <SectionFive />
      <SectionSix />
    </>
  );
}

export default AllSections;
