import React from "react";
import "./Right_side_highlight_watchserieslogo.css";
import watchserieslogo from "../../../../src/commonResources/images/icons/watch-series5-logo.png";
function Right_side_highlight_watchserieslogo() {
  return (
    <div>
      <section class="fifth-heghlight-wrapper">
        <div class="container-fluid">
          <div class="row">
            <div class="right-side-wrapper col-sm-12 col-md-6">
              <div class="right-side-container">
                <div class="top-logo-wrapper">
                  <div class="logo-wrapper">
                    <img src={watchserieslogo} alt="Watch Series Logo" />
                  </div>
                </div>
                <div class="description-wraper">
                  With the Always-On Retina display.
                  <br />
                  You’ve never seen a watch like this.
                </div>
                <div class="links-wrapper">
                  <ul>
                    <li>
                      <a href="">Learn more</a>
                    </li>
                    <li>
                      <a href="">Buy</a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

export default Right_side_highlight_watchserieslogo;
